# ============================
# Verificar permisos de administrador
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "⚠️ This script requires administrator permissions. Restarting with privileges..."
    Start-Process powershell "-ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# ============================
# Crear punto de restauración
Checkpoint-Computer -Description "WindowsUltimatePerfDebloat" -RestorePointType "MODIFY_SETTINGS"

# Aviso de seguridad
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show(
    "A restore point 'WindowsUltimatePerfDebloat' has been created. If something goes wrong, use it to recover your system.",
    "⚠️ Recovery Info",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
)

# ============================
# Windows Ultimate Performance Debloat
# ============================

# CPU: desactivar reposo profundo
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -Name "ProcessorIdleDisable" -Value 1

# CPU: prioridad procesos en primer plano
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl" -Name "Win32PrioritySeparation" -Value 26

# Memoria: caché L2 de 2 MB
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name "SecondLevelDataCache" -Value 2048

# Kernel: desactivar DynamicTick
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" -Name "EnableDynamicTick" -Value 0

# ============================
# Pop-up de reinicio
# ============================
$resultRestart = [System.Windows.Forms.MessageBox]::Show(
    "Restart your PC now to apply changes",
    "⚠️ Important",
    [System.Windows.Forms.MessageBoxButtons]::OKCancel,
    [System.Windows.Forms.MessageBoxIcon]::Exclamation
)

if ($resultRestart -eq [System.Windows.Forms.DialogResult]::OK) {
    Restart-Computer -Force
} else {
    Write-Host "You chose to restart later. Please remember to restart manually."
}

# ============================
# Revertir cambios si algo falla
# ============================
function Revert-Changes {
    # CPU: volver a reposo
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -Name "ProcessorIdleDisable" -Value 0

    # CPU: prioridad estándar
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl" -Name "Win32PrioritySeparation" -Value 2

    # Memoria: caché L2 sin definir
    Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name "SecondLevelDataCache" -ErrorAction SilentlyContinue

    # Kernel: activar DynamicTick
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" -Name "EnableDynamicTick" -Value 1

    Write-Host "✅ Changes reverted to default values."
}

# Preguntar al usuario si quiere revertir
$resultRevert = [System.Windows.Forms.MessageBox]::Show(
    "Do you want to revert all changes to default settings?",
    "Recovery Option",
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Question
)

if ($resultRevert -eq [System.Windows.Forms.DialogResult]::Yes) {
    Revert-Changes
}

# ============================
# Mensaje final
# ============================
Write-Host "✅ Script finished. Restart or revert as needed."